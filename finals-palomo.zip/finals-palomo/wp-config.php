<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'finals-palomo' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '^m 1T/#?a%F](QaRf+kDgjyAA:QSz0?=8zFf#p>EZrzDJHFP2PwgZU<E)iY1;k5I' );
define( 'SECURE_AUTH_KEY',  'C1KZxuYKp!.?As$UUIp[?MAl*f9< *v;8?Hj%r2G[W_3nV-nz>(`*E[i|/}d|joA' );
define( 'LOGGED_IN_KEY',    '8 MPMzco te5=w9b6/lm`Tr[|Zz)(ca-K?*C2KM1{h8lY>6cz%KB7n;Nbjn69%^+' );
define( 'NONCE_KEY',        'YNf>d52)+p:AVb+qinn~wQa+CyTSfhZ)3*uT!^8CvDyl^yn6J^x{&l:[F.FU){Ra' );
define( 'AUTH_SALT',        'z]x9=kghaf[E<H6G})YMzp3w(I8CUW[xWW%ExV.;~)B[x.+qd5lDO96Z}$x-:!8o' );
define( 'SECURE_AUTH_SALT', 'K@BeS&4Yyo}*qjR*Hz0Vxx:PDeiT-;N34HnB-$?B3ezp}v002.-~rcOtbMhD7w,a' );
define( 'LOGGED_IN_SALT',   '$:q],a2g4e6:2&-P(8K{h2mVexedtuz|Kf~=c7w-[hw+C!V$42^S!.kDW5Z~5(hx' );
define( 'NONCE_SALT',       'wgXR~/I3Rp``OwSjHkwgLl9J?tu]p*^jr(1A.ZOlC|aw/KsuM9sh0Ihn#PrFBHWb' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
